﻿var settings = {
  "commandCooldown": 10,
  "messageDuringCOTD": "The current TOTD is '{trackName}' by {authorName} with an author time of {authorTime}. COTD {stage} stage in progress!",
  "messageBeforeCOTD": "The current TOTD is '{trackName}' by {authorName} with an author time of {authorTime}. The next COTD starts in {countdown}"
};