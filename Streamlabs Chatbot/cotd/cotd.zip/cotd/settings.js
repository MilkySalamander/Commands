﻿var settings = {
  "accountID": "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX",
  "nickname": "Milky",
  "commandCooldown": 10,
  "messageCOTD": "",
  "messageBeforeCOTD": "The current TOTD is '{trackName}' by {authorName} with an author time of {authorTime}. The next COTD starts in {countdown}",
  "messageDuringCOTD": "The current TOTD is '{trackName}' by {authorName} with an author time of {authorTime}. COTD {stage} stage in progress!"
};